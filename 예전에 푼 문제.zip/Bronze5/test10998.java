package Bronze5;

public class test10998 {

}
