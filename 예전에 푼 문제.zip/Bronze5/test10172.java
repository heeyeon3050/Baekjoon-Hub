package Bronze5;

public class test10172 {
	public static void main(String[] args) {
		StringBuilder sb = new StringBuilder();
		sb.append("|\\_/|").append("\n");
		sb.append("|q p|   /}").append("\n");
		sb.append("( 0 )\"\"\"\\").append("\n");
		sb.append("|\"^\"`    |").append("\n");
		sb.append("||_/=\\\\__|").append("\n");
		
		System.out.println(sb);
	}
}