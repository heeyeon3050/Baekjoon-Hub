package Bronze5;

public class test10171 {
	public static void main(String[] args) {
		StringBuilder sb = new StringBuilder();
		sb.append("\\    /\\").append("\n");
		sb.append(" )  ( ')").append("\n");
		sb.append("(  /  )").append("\n");
		sb.append(" \\(__)|").append("\n");
		
		System.out.println(sb);
	}
}
