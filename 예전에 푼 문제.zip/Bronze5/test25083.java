package Bronze5;

public class test25083 {
	public static void main(String[] args) {
		StringBuilder sb = new StringBuilder();
		
		sb.append("         ,r'\"7").append("\n");
		sb.append("r`-_   ,'  ,/").append("\n");
		sb.append(" \\. \". L_r'").append("\n");
		sb.append("   `~\\/").append("\n");
		sb.append("      |").append("\n");
		sb.append("      |").append("\n");
		
		System.out.println(sb);
	}
}
